# FYP ESP FC member artwork package verification

Completed: removed all remaining rear ESP BLAST lettering and Rocket Drone Flight Controller subtitle; added three ordered member groups; preserved top FYP ESP FC and earlier creator/version removals; retained-geometry equality, file SHA256, Gerber parsing, preview and ZIP integrity checks. Failed: none. Unattempted: circuit review, full DRC or broad fabrication approval (outside artwork scope, no editable board).

Computer: gerber-artwork (EDA). Baseline /root/work/artwork/renamed; edited package /root/work/artwork/members. Scripts: add_members.py, render_members.py, verify_members.py. Detailed geometry /root/work/artwork/members-summary.json. Deliverables /root/out. No Flux project import/reconstruction/mutation.

A full name plus ID cannot fit each row at the requested readable size in the available strip. Used six aligned rows, two per member, in exact requested order:

Shahzeb Niaz
(22i-2152)

Anas Bilal
(22i-2248)

Auon Bangash
(22i-2180)

Font: Hershey futural clean stroke sans-serif, same scale for every glyph (0.045 mm/font unit), 0.160 mm round strokes. Parentheses resized to cap-height rather than oversized font punctuation. Row ink heights 1.15 mm except descender-containing Auon Bangash at 1.42 mm; nominal cap centerline height 0.945 mm, cap ink height 1.105 mm. Same physical-bottom left alignment (Gerber x=32.8 mm), inside-pair ink gap 0.18 mm, between groups 0.27 mm. Mirrored Gerber X coordinates make the physical underside readable. Uses removed title/subtitle strip plus safe blank space from earlier creator removal.
Removed 238 line primitives and 8 regions; added 624 line primitives. Bottom objects 2235 -> 2613; no bottom regions remain. New ink bounding box mm [[22.865000000000002, -52.9], [32.879999999999995, -44.65]].
Minimum conservative clearance from new stroke ink to bottom solder-mask-opening bounding boxes: 0.284 mm. To retained functional-silk bounding boxes: 0.312 mm. Bounding-box tests understate true geometry clearance; both exceed 0.20 mm. All new art remains on solid board within outline, confirmed on full-board rendering; no exposed pads or retained functional marking overlap.

Reparsed remaining original object sequence matches geometry primitives, attributes and polarity exactly. Removed draw commands become moves; selected region delimiters become comments. All modal coordinates/apertures/interpolation/polarity retained; appended isolated dark/linear D99 0.160 mm stroke block. Top silk is byte-identical to baseline. All 21 non-silk regular members are byte-identical both to baseline and original package, including copper, masks, paste, drills, outline, BOMs, pick-and-place and licensing/provenance README. Only bottom silk changed.

Read-only final preview inspected: exact member spelling/IDs/order, readable physical-bottom orientation, no rear ESP BLAST/subtitle, no Max Imagination/version label, retained 2026 and connector markings, unchanged top FYP ESP FC. Preview is 2D fabrication artwork, not assembled-component rendering.

Tools: gerbonara 1.6.3, Hershey-Fonts futural, CairoSVG 2.9.1, Pillow 12.3.0; installed KiCad CLI 10.0.6 (not used to rebuild). All 11 Gerbers plus Excellon drill parse successfully, PNG render succeeds, ZIP CRC test passes. Warning: unchanged original drill G90 after header end is accepted by parser.

esp-blast-rocket-drone-controller-b_cu.gbr: PASS, 480 objects
esp-blast-rocket-drone-controller-b_mask.gbr: PASS, 101 objects
esp-blast-rocket-drone-controller-b_paste.gbr: PASS, 101 objects
esp-blast-rocket-drone-controller-b_silks.gbr: PASS, 2613 objects
esp-blast-rocket-drone-controller-edge_cuts.gbr: PASS, 274 objects
esp-blast-rocket-drone-controller-f_cu.gbr: PASS, 403 objects
esp-blast-rocket-drone-controller-f_mask.gbr: PASS, 96 objects
esp-blast-rocket-drone-controller-f_paste.gbr: PASS, 96 objects
esp-blast-rocket-drone-controller-f_silks.gbr: PASS, 1413 objects
esp-blast-rocket-drone-controller-in1_cu.gbr: PASS, 50 objects
esp-blast-rocket-drone-controller-in2_cu.gbr: PASS, 154 objects

## SHA256 against previous package
| File | Previous SHA256 | New SHA256 | Result |
|---|---|---|---|
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-AdvancedCircuits.csv | 0ee904f5d1f7a12510baf3a5420cd8f1504abf1305ef1cfbe219f9ff177c1f0f | 0ee904f5d1f7a12510baf3a5420cd8f1504abf1305ef1cfbe219f9ff177c1f0f | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-AllPCB.csv | ee2fbf35bfff2ca678ca1537f6149e30eca48eb42fbf08636ddfa94f8a82684d | ee2fbf35bfff2ca678ca1537f6149e30eca48eb42fbf08636ddfa94f8a82684d | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-Elecrow.csv | 3039827ec251edceff7661cbbe5c207bafd96c32a9261b2de2feeb0905dfbeb5 | 3039827ec251edceff7661cbbe5c207bafd96c32a9261b2de2feeb0905dfbeb5 | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-Eurocircuits.csv | 19b525924475e6ef2c0c6c653e0b4224de71aff00494fb4859661094ccde2b05 | 19b525924475e6ef2c0c6c653e0b4224de71aff00494fb4859661094ccde2b05 | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-Flux.csv | 2f89870ab91782f59186f0e28186ef22418b81c095836e4ba3871aa7b6237309 | 2f89870ab91782f59186f0e28186ef22418b81c095836e4ba3871aa7b6237309 | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-JLCPCB.csv | 3d2ceae3bfbf7d0d17be5c6bc4fb834d25242de96d8cb6fe9d5583433b55645e | 3d2ceae3bfbf7d0d17be5c6bc4fb834d25242de96d8cb6fe9d5583433b55645e | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-PCBWay.csv | acca0d193ec870417ee180e325eff31706975c8161ac76d259c13b35f4a9c1d6 | acca0d193ec870417ee180e325eff31706975c8161ac76d259c13b35f4a9c1d6 | UNCHANGED |
| BOM/maximagination-esp-blast-rocket-drone-controller-BOM-Vd50b76ff-Seeed.csv | d5605f4132546dcbd99d2de81efc7cb8a8c41ba99a5749730fb0a5efa7c9f52b | d5605f4132546dcbd99d2de81efc7cb8a8c41ba99a5749730fb0a5efa7c9f52b | UNCHANGED |
| esp-blast-rocket-drone-controller-b_cu.gbr | 4947ece5c9e67bdeba82601b3136dcb76a09ca3defbbeb19643a23f5470cd396 | 4947ece5c9e67bdeba82601b3136dcb76a09ca3defbbeb19643a23f5470cd396 | UNCHANGED |
| esp-blast-rocket-drone-controller-b_mask.gbr | 1669e7d3aee2dec5c40dda868d03d989ca11eb0fd7c85cfca34b24f8d3d48ccf | 1669e7d3aee2dec5c40dda868d03d989ca11eb0fd7c85cfca34b24f8d3d48ccf | UNCHANGED |
| esp-blast-rocket-drone-controller-b_paste.gbr | 97cb82ea37cb721fc7619c3198732d097803ba8d9dc84cb4670abed0af43cf38 | 97cb82ea37cb721fc7619c3198732d097803ba8d9dc84cb4670abed0af43cf38 | UNCHANGED |
| esp-blast-rocket-drone-controller-b_silks.gbr | 28183ab17f86452371f7cf47662596595d4708dbf1b66719f134509bc9c200c1 | 32e813b7a3cb2fc3380c990713172f40b9d1fe4be51e949f7171f221c52ed035 | AUTHORIZED BOTTOM SILK EDIT |
| esp-blast-rocket-drone-controller-edge_cuts.gbr | 7bcb6fb64c9c4d557e6f77e30499a8a1a169601e59fc2ee2b7a7fd6aec10b48d | 7bcb6fb64c9c4d557e6f77e30499a8a1a169601e59fc2ee2b7a7fd6aec10b48d | UNCHANGED |
| esp-blast-rocket-drone-controller-f_cu.gbr | fd289d4a9da65b5da81d58e925758a2581ba111a1477b2329c0c35d7f00d4954 | fd289d4a9da65b5da81d58e925758a2581ba111a1477b2329c0c35d7f00d4954 | UNCHANGED |
| esp-blast-rocket-drone-controller-f_mask.gbr | 8d21ab6ee1fbf43ce4d75301a9729d538394aff88000a479339b712d1ffaa5e2 | 8d21ab6ee1fbf43ce4d75301a9729d538394aff88000a479339b712d1ffaa5e2 | UNCHANGED |
| esp-blast-rocket-drone-controller-f_paste.gbr | 9136d3b10b95fa6032d1deb2169f3cf18e249569484cc2db6f5a6580bb25e602 | 9136d3b10b95fa6032d1deb2169f3cf18e249569484cc2db6f5a6580bb25e602 | UNCHANGED |
| esp-blast-rocket-drone-controller-f_silks.gbr | f3f1d87c8c59a699c81fc708669ee05e38927f97a1682574e4c03bf287b10f06 | f3f1d87c8c59a699c81fc708669ee05e38927f97a1682574e4c03bf287b10f06 | UNCHANGED |
| esp-blast-rocket-drone-controller-in1_cu.gbr | f4e8e20dbf60dd80e5b55a52a49ba8b42b66823d5e25473d950c7e32975828a4 | f4e8e20dbf60dd80e5b55a52a49ba8b42b66823d5e25473d950c7e32975828a4 | UNCHANGED |
| esp-blast-rocket-drone-controller-in2_cu.gbr | 02d5ef26737d764bce3254e36edee06db8058615890789d4e226fdc126ccfa5d | 02d5ef26737d764bce3254e36edee06db8058615890789d4e226fdc126ccfa5d | UNCHANGED |
| esp-blast-rocket-drone-controller.d356 | 6933c5b3a6cc88440812ed4b58e7afed0405864145cc51b31ccc3165ce3772bf | 6933c5b3a6cc88440812ed4b58e7afed0405864145cc51b31ccc3165ce3772bf | UNCHANGED |
| esp-blast-rocket-drone-controller.drl | 47e15a8441a065b346903867828e46b9c526a20d64b302239806699a0f3eebdb | 47e15a8441a065b346903867828e46b9c526a20d64b302239806699a0f3eebdb | UNCHANGED |
| pick_and_place.csv | 65fee2446bd44c504bb672b47d77ab62ae50c9294111b0adf4decf786f07f904 | 65fee2446bd44c504bb672b47d77ab62ae50c9294111b0adf4decf786f07f904 | UNCHANGED |
| readme.txt | 9c125a4fd7ceaea9351e504c8a7fe951a8607ee8157553f3d79e544d9c3f9fab | 9c125a4fd7ceaea9351e504c8a7fe951a8607ee8157553f3d79e544d9c3f9fab | UNCHANGED |

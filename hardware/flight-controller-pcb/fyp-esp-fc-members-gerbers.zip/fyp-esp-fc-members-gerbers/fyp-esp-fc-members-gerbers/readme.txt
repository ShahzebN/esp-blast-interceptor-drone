Project Name: ESP-BLAST Rocket Drone Controller
Project Version: #d50b76ff
Project Url: https://www.flux.ai/maximagination/esp-blast-rocket-drone-controller~1r

Project Description:
ESP32-WROOM-32U Based Flight Controller (Drop-in Replacement for ESP32-S3-MINI-1-N8) with Preserved GPIO/Peripheral Mappings and Updated Power/Support Circuitry

Project Properties:

Operating Voltage:
12

Design Architecture Diagram:
flowchart TD
    VBAT[VBAT Input]
    L7805[L7805 5V]
    AMS1117[AMS1117 3.3V]
    VBAT_DIVIDER[VBAT Divider]
    ESP32[ESP32-S]
    FTDI[FTDI Header]
    MPU9250[MPU9250]
    GPS[GPS]
    BUZZER_MOSFET[Buzzer MOSFET]
    SERVO[Servo Header]
    ESC[ESC Connectors]
    MINIMOSD[MinimOSD]

    VBAT --> L7805
    L7805 --> AMS1117
    VBAT --> VBAT_DIVIDER
    AMS1117 --> ESP32
    L7805 --> FTDI
    L7805 --> MPU9250
    L7805 --> GPS
    L7805 --> MINIMOSD
    L7805 --> BUZZER_MOSFET
    ESP32 --> FTDI
    ESP32 --> MPU9250
    ESP32 --> GPS
    ESP32 --> BUZZER_MOSFET
    ESP32 --> SERVO
    ESP32 --> ESC
    ESP32 --> MINIMOSD
    VBAT_DIVIDER --> ESP32

Software:
Arduino

Domain:
Aerospace

Power Requirements:
Battery

Connectivity:
WiFi

System Architecture:
flowchart TD
    ESP32WROOM32U["ESP32-WROOM-32U"]
    TX0["TX0 - GPIO1"]
    RX0["RX0 - GPIO3"]
    LED["Status LED - IO2"]
    BOOT["BOOT - IO0"]
    BUZZER["Buzzer/ESC LED - IO5"]
    SERVO["Servo Control - IO12"]
    ESC1["ESC1 - IO14"]
    ESC2["ESC2 - IO25"]
    ESC3["ESC3 - IO26"]
    ESC4["ESC4 - IO27"]
    GPS_TX["GPS TX - IO16"]
    GPS_RX["GPS RX - IO17"]
    I2C_SCL["I2C SCL - IO21"]
    I2C_SDA["I2C SDA - IO22"]
    OSD_RX["MinimOSD RX - IO32"]
    OSD_TX["MinimOSD TX - IO33"]
    VBAT_ADC["VBAT ADC - IO36"]
    ESP32WROOM32U --> TX0
    ESP32WROOM32U --> RX0
    ESP32WROOM32U --> LED
    ESP32WROOM32U --> BOOT
    ESP32WROOM32U --> BUZZER
    ESP32WROOM32U --> SERVO
    ESP32WROOM32U --> ESC1
    ESP32WROOM32U --> ESC2
    ESP32WROOM32U --> ESC3
    ESP32WROOM32U --> ESC4
    ESP32WROOM32U --> GPS_TX
    ESP32WROOM32U --> GPS_RX
    ESP32WROOM32U --> I2C_SCL
    ESP32WROOM32U --> I2C_SDA
    ESP32WROOM32U --> OSD_RX
    ESP32WROOM32U --> OSD_TX
    ESP32WROOM32U --> VBAT_ADC

Manufacturing Quantity Target:
5

Reference Design URL:
[object Object]

License:
http://solderpad.org/licenses/SHL-2.1/

undefined:
undefined


